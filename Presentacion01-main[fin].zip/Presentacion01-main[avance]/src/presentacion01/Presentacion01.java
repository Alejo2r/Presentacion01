/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package presentacion01;

import java.util.Scanner;

/**
 *
 * @author Admin
 */
public class Presentacion01 {
static Scanner lea = new Scanner(System.in);
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Jugador j = null; 
        Guerreromono m = null;
        GuerreroMago g = null;
        Combatiente c = null;
        Orco o = null;
        DragonInfernal d = null;
        play(j, m, g, c, o, d);
        
    }
   public static void play(Jugador j, Guerreromono m, GuerreroMago g, Combatiente c, Orco o, DragonInfernal d){
        int op;
        System.out.println("Ingrese su nombre j1");
        String n = lea.next();
        j = new Jugador(100, n, 50, "Humano", 50 );
        m = new Guerreromono(2000, 1500, "Mono", 2000, "Wukong");
        g = new GuerreroMago(1000, 2000, "Odette", "Humano", 1000);
        c = new Combatiente(1500, 1000, "Lapu Lapu", "Humano", 1250);
        o = new Orco(2500, 1500, "Gul*dan", "Bestia", 1500);
        d = new DragonInfernal(3250, 1950, "Alduin", "Bestia", 1950);
       
       
       
        do{
            System.out.println("--------------MENU PRINCIPAL--------------");
            System.out.println("1) Ver estadisticas del jugador");
            System.out.println("2) Ver estadisticas de enemigos");
            System.out.println("3) Entrenamiento");
            System.out.println("4) Modo Historia");
            System.out.println("5) Salir del Juego");
            op = lea.nextInt();
            switch(op){
                case 1:
                    estadisticas(j);
                    break;
                case 2:
                    System.out.println("Seleccione el tipo de enemigo ");
                    System.out.println("1) Guerrero Mono");
                    System.out.println("2) Guerrero Mago");
                    System.out.println("3) Combatiente");
                    System.out.println("4) Orco");
                    System.out.println("5) Dragon Infernal");
                    int resp = lea.nextInt();
                   
                        switch(resp){
                            case 1:
                                enemigos(m);
                                break;
                            case 2:
                                enemigos(g);
                                break;
                            case 3:
                                combatiente(c);
                                break;
                            case 4:
                                orco(o);
                                break;
                            case 5:
                                drag(d);
                                break;
                            default:
                                System.out.println("Numero no valido");
                                break;
                        }                        
                        
                    break;
                case 3: 
                    j.mejorar();
                  
                    break;
                case 4:
                    int nivel = 1;

                    System.out.println("**** Empecemos la Aventura ****");

                    while (j.getVida() > 0) {
                        System.out.println("Nivel actual: " + nivel);
                        System.out.println("1) Avanzar en el nivel " + nivel);
                        System.out.println("2) Regresar al Menu Principal");
                        int opcion = lea.nextInt();

                        if (opcion == 1) {
                            boolean combateGanado = false;
                            switch (nivel) {                    
                                case 1: // Guerrero Mono
                                    combateGanado = combate(j, m.getNombre(), m.getVida(), m.getFuerza(), m.getDefensa());
                                    break;                    
                                case 2: // Guerrero Mago
                                    combateGanado = combate(j, g.getNombre(), g.getVida(), g.getFuerza(), g.getDefensa());
                                    break;                    
                                case 3: // Combatiente
                                    combateGanado = combate(j, c.getNombre(), c.getVida(), c.getFuerza(), c.getDefensa());
                                    break;
                                case 4: // Orco
                                    combateGanado = combate(j, o.getNombre(), o.getVida(), o.getFuerza(), o.getDefensa());
                                    break;
                                case 5: // Dragón Infernal
                                    combateGanado = combate(j, d.getNombre(), d.getVida(), d.getFuerza(), d.getDefensa());
                                    if (combateGanado) {
                                        System.out.println("Felicitaciones! Has completado la historia!");
                                        break;
                                    }
                                    break;
                            }
                            
                            if (combateGanado) {
                                bonificacion(j); 
                                if (nivel < 5) {
                                    nivel++; 
                                }
                            } else {
                                System.out.println("Perdiste el combate! Regresando al menu principal...");
                                break;
                            }
                        } else if (opcion == 2) {
                            System.out.println("Regresando al Menu Principal...");
                            break;
                        } else {
                            System.out.println("Opcion no valida. Intenta de nuevo.");
                        }
                    }
                    break;
                case 5:
                    System.out.println("Saliendo del juego...");
                    System.exit(0);
                    break;
            default: System.out.println("Numero no valido");
            break;
               
           }
       }while(j.getVida() >= 0);
   }
   public static void estadisticas(Jugador j){
       System.out.println("***** Estadisticas del Jugador *****");
       System.out.println("Vida: "+ j.getVida());
       System.out.println("Nombre: "+ j.getNombre());
       System.out.println("Poder: "+ j.getPoder());
       System.out.println("Especie: "+ j.getEspecie());
       System.out.println("Defensa: "+ j.getDefensa());
   }
   public static void enemigos(Guerreromono m){
       System.out.println("***** Estadisticas de los Enemigos *****");
       System.out.println("Nombre: "+ m.getNombre());
       System.out.println("Vida: "+ m.getVida());
       System.out.println("Poder: "+ m.getFuerza());
       System.out.println("Especie: "+ m.getEspecie());
       System.out.println("Defensa: "+ m.getDefensa()); 
   }
   public static void enemigos(GuerreroMago mago){
       System.out.println("***** Estadisticas de los Enemigos *****");
       System.out.println("Nombre: "+ mago.getNombre());
       System.out.println("Vida: "+ mago.getVida());
       System.out.println("Poder: "+ mago.getFuerza());
       System.out.println("Especie: "+ mago.getEspecie());
       System.out.println("Defensa: "+ mago.getDefensa());
   }
   public static void combatiente(Combatiente c){
       System.out.println("***** Estadisticas de los Enemigos *****");
       System.out.println("Nombre: "+ c.getNombre());
       System.out.println("Vida: "+ c.getVida());
       System.out.println("Poder: "+ c.getFuerza());
       System.out.println("Especie: "+ c.getEspecie());
       System.out.println("Defensa: "+ c.getDefensa()); 
   }

    public static void orco(Orco o) {
       System.out.println("***** Estadisticas de los Enemigos *****");
       System.out.println("Nombre: "+ o.getNombre());
       System.out.println("Vida: "+ o.getVida());
       System.out.println("Poder: "+ o.getFuerza());
       System.out.println("Especie: "+ o.getEspecie());
       System.out.println("Defensa: "+ o.getDefensa());
    }

    public static void drag(DragonInfernal d) {
        System.out.println("***** Estadisticas de los Enemigos *****");
       System.out.println("Nombre: "+ d.getNombre());
       System.out.println("Vida: "+ d.getVida());
       System.out.println("Poder: "+ d.getFuerza());
       System.out.println("Especie: "+ d.getEspecie());
       System.out.println("Defensa: "+ d.getDefensa());
    }   
    
    public static boolean combate(Jugador j, String Enemigo, int vida, int fuerza, int defensa) {
        System.out.println("Inicia el combate contra " + Enemigo + "!");
            int juga_v = j.getVida();
        while (juga_v > 0 && vida > 0) {
            
            int dañoJ = j.getPoder() - defensa;
            int dañoE = fuerza - j.getDefensa();

            vida -= (dañoJ > 0) ? dañoJ : 0;
            juga_v = (juga_v - ((dañoE > 0) ? dañoE : 0));
        }

        if (vida <= 0) {
            System.out.println("Has derrotado a " + Enemigo + "!");
            return true;
        } else if (juga_v <= 0) {
            System.out.println("Has sido derrotado por " + Enemigo + ".");            
            return false;
        }
        return false;
    }   


    public static void bonificacion(Jugador j) {
        j.setVida(j.getVida() + 100);
        j.setPoder(j.getPoder() + 100);
        j.setDefensa(j.getDefensa() + 100);
        System.out.println("Has recibido una bonificacion! Vida, Poder y Defensa aumentados en 100.");
    }
   
}
