/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package presentacion01;

/**
 *
 * @author danie
 */
public class Combatiente {
    
    private int vida;
    private int fuerza;
    private String nombre;
    private String especie;
    private int defensa;

    public Combatiente() {
    }

    public Combatiente(int vida, int fuerza, String nombre, String especie, int defensa) {
        this.vida = vida;
        this.fuerza = fuerza;
        this.nombre = nombre;
        this.especie = especie;
        this.defensa = defensa;
    }

    public int getVida() {
        return vida;
    }

    public void setVida(int vida) {
        this.vida = vida;
    }

    public int getFuerza() {
        return fuerza;
    }

    public void setFuerza(int fuerza) {
        this.fuerza = fuerza;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEspecie() {
        return especie;
    }

    public void setEspecie(String especie) {
        this.especie = especie;
    }

    public int getDefensa() {
        return defensa;
    }

    public void setDefensa(int defensa) {
        this.defensa = defensa;
    }
    
    
}
